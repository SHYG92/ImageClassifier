import torch
import torch.nn as nn
import torch.optim as optim
import torch.utils.data as data

import torchvision.models as models
import torchvision.transforms as transforms
import torchvision.datasets as datasets

import argparse

#allow user to train NN by specifying dataset, number of epochs, model architecture, learning rate, number of hidden units and save it to checkpoint file
parser = argparse.ArgumentParser()
parser.add_argument('--data_dir', type=str, help='Path to Dataset')
parser.add_argument('--arch', type=str, help='Model Architecture')
parser.add_argument('--gpu', action='store_true', help='to use GPU or CPU')
parser.add_argument('--epochs', type=int, help='Number of Epochs')
parser.add_argument('--hidden_units', type=int, help='Number of Hidden Units')
parser.add_argument('--learning_rate', type=float, help='Learning Rate')
parser.add_argument('--checkpoint', type=str, help='Save trained model checkpoint to file')

args, _ = parser.parse_known_args()

#load model
def load_model(arch='vgg19', num_labels=102, hidden_units=4096):
    if arch == 'vgg19':
        sy_model = models.vgg19(pretrained=True)
    elif arch == 'alexnet':
        sy_model = models.alexnet(pretrained=True)
    else:
        raise ValueError('Unexpected Network Architecture', arch)
        
    #Freeze its parameters
    for param in sy_model.parameters():
        param.required_grad = False
            
    features = list(sy_model.classifier.children())[:-1]
    num_filters = sy_model.classifier[len(features)].in_features
        
    features.extend([
        nn.Dropout(),
        nn.Linear(num_filters, hidden_units),
        nn.ReLU(True),
        nn.Dropout(),
        nn.Linear(hidden_units, hidden_units),
        nn.ReLU(True),
        nn.Linear(hidden_units, num_labels),
        nn.Softmax(dim=1)
    ])
    print('num_filters:', num_filters) #assure the number of filters
    #print(num_filters) 
    
    sy_model.classifier = nn.Sequential(*features)
    
    print('Model Successfully Loaded')
        
    return sy_model

#Model Training
def train_model(image_datasets, arch='vgg19', hidden_units=4096, epochs=25, learning_rate=0.001, gpu=False, checkpoint=''):
    if args.arch:
        arch = args.arch
    if args.hidden_units:
        hidden_units = args.hidden_units
    if args.epochs:
        epochs = args.epochs
    if args.learning_rate:
        learning_rate = args.learning_rate
    if args.gpu:
        gpu = args.gpu
    if args.checkpoint:
        checkpoint = args.checkpoint
    
    dataloaders = {
        x: data.DataLoader(image_datasets[x], batch_size=10, shuffle=True, num_workers=2)
        for x in list(image_datasets.keys())
    }
    
    dataset_sizes = {
        x: len(dataloaders[x].dataset)
        for x in list(image_datasets.keys())
    }
    
    print('Network Architecture: ', arch)
    print('Number of Hidden Units: ', hidden_units)
    print('Number of Epochs: ', epochs)
    print('Learning Rate: ', learning_rate)
    
    num_labels = len(image_datasets['train'].classes)
    sy_model = load_model(arch=arch, num_labels=num_labels, hidden_units=hidden_units)
    
    if gpu and torch.cuda.is_available():
        print('GPU Training')
        device = torch.device("cuda:0")
        sy_model.cuda()
    else:
        print('CPU Training')
        device = torch.device("cpu")
        
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(list(filter(lambda p: p.requires_grad, sy_model.parameters())), lr=learning_rate, momentum=0.9)
    
    for epoch in range(epochs):
        print('-' * 21)
        print('Epoch {}/{}'.format(epoch+1, epochs))
        for phase in ['train', 'valid']:
            if phase == 'train':
                sy_model.train()
            else:
                sy_model.eval()
            running_loss = 0.0
            running_correct = 0
            for inputs, labels in dataloaders[phase]:
                inputs = inputs.to(device)
                labels = labels.to(device)
                optimizer.zero_grad()
                with torch.set_grad_enabled(phase == 'train'):
                    outputs = sy_model(inputs)
                    _, preds = torch.max(outputs,1)
                    loss = criterion(outputs, labels)
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()
                #training loss, validation loss and validation accuracy
                #print(phase)
                running_loss+= loss.item() * inputs.size(0)
                running_correct+= torch.sum(preds == labels.data)
                
            epoch_loss = running_loss/dataset_sizes[phase]
            epoch_acc = running_correct.double()/dataset_sizes[phase]
            print('{} loss: {:.4f} Acc: {:.4f}'.format(phase, epoch_loss, epoch_acc))
        
    sy_model.class_to_idx = image_datasets['train'].class_to_idx
        
    if args.checkpoint:
        print('Saving Checkpoint to: ', checkpoint)
        checkpoint_dict = {
            'arch': arch,
            'class_to_idx': sy_model.class_to_idx,
            'state_dict': sy_model.state_dict(),
            'hidden_units': hidden_units
        }
        torch.save(checkpoint_dict, checkpoint)
        
    return sy_model

#Command Line Argument Normalization
if args.data_dir:
    data_transforms = {
        'train': transforms.Compose([
            transforms.RandomRotation(45),
            transforms.RandomResizedCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ]),
        'valid': transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ]),
        'test': transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
    }
    image_datasets = {
        x: datasets.ImageFolder(root=args.data_dir + '/' + x, transform=data_transforms[x])
        for x in list(data_transforms.keys())
    }
    train_model(image_datasets)
