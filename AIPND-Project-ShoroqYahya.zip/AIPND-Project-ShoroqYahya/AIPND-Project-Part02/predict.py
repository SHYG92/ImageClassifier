#!/usr/bin/env python
# -*- coding: ascii -*-

import torch
from torch.autograd import Variable

import torchvision.transforms as transforms

import numpy as np
from PIL import Image
from train import load_model

import json
import argparse

#allow user to predict an image, specify checkpoint, labels, topk and if to use GPU or not
parser = argparse.ArgumentParser()
parser.add_argument('--image', type=str, help='Image to predict')
parser.add_argument('--checkpoint', type=str, help='Model Checkpoint to use when predicting')
parser.add_argument('--topk', type=int, help='Print out Top k predictions')
parser.add_argument('--labels', type=str, help='JSON file that contains labels names')
parser.add_argument('--gpu', action='store_true', help='to use GPU or CPU')

args, _ = parser.parse_known_args()

#predict method
def predict(image, checkpoint, topk=5, labels='', gpu=False):
    if args.image:
        image = args.image
    if args.checkpoint:
        checkpoint = args.checkpoint
    if args.topk:
        topk = args.topk
    if args.labels:
        labels = args.labels
    if args.gpu:
        gpu = args.gpu
    
    #Model Setup
    checkpoint_dict = torch.load(checkpoint)
    arch = checkpoint_dict['arch']
    num_labels = len(checkpoint_dict['class_to_idx'])
    hidden_units = checkpoint_dict['hidden_units']
    
    sy_model = load_model(arch=arch, num_labels=num_labels, hidden_units=hidden_units)
    
    if gpu and torch.cuda.is_available():
        sy_model.cuda()
       
    was_training = sy_model.training
    sy_model.eval()
    
    #Image Loading and Normalization
    img_loader = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor()])
    
    pil_image = Image.open(image)
    pil_image = img_loader(pil_image).float()
    
    image = np.array(pil_image)
    
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    image = (np.transpose(image, (1,2,0))-mean)/std
    image = np.transpose(image, (2,0,1))
    image = Variable(torch.FloatTensor(image), requires_grad=True)
    image = image.unsqueeze(0)
    
    if gpu and torch.cuda.is_available() :
        image = image.cuda()
        
    result = sy_model(image).topk(topk)
    
    if gpu and torch.cuda.is_available():
        probs = torch.nn.functional.softmax(result[0].data, dim=1).cpu().numpy()[0]
        classes = result[1].data.cpu().numpy()[0]
        
    else:
        probs = torch.nn.functional.softmax(result[0].data, dim=1).numpy()[0]
        classes = result[1].data.numpy()[0]
        
    if labels:
        with open(labels, 'r') as f:
            cat_to_name = json.load(f)
            
    sy_model.class_to_idx = checkpoint_dict['class_to_idx']
    idx_to_class = {val: key for key, val in sy_model.class_to_idx.items()}
    topk_labels = [idx_to_class[label] for label in classes]
    topk_class_names = [cat_to_name[idx_to_class[label]] for label in classes]
    
    sy_model.train(mode=was_training)
    
    #print out probs and classes
    if args.image:
        print('Predictions and Probabailities: ', list(zip(topk_class_names, probs))) #classes
        print('Successfully Predicted')
        
    return probs, topk_class_names

if args.image and args.checkpoint:
    predict(args.image, args.checkpoint)
